INSERT INTO Users
(full_name,email,city,registration_date)
VALUES
('Anusha','anusha@gmail.com','Hyderabad','2026-03-2'),
('Arun','arun@gmail.com','Warangal','2026-04-2');

INSERT INTO Events
(title,description,city,start_date,end_date,status)
VALUES
('Coding Workshop',
 'Learn HTML CSS JS',
 'Hyderabad',
 '2026-03-01',
 '2026-06-01',
 'Upcoming');

INSERT INTO Registrations
(user_id,event_id,registration_date)
VALUE
(1,1,'2026-05-25');

INSERT INTO Feedback
(user_id,event_id,rating,comments)
VALUES
(1,1,5,'Excellent Event');