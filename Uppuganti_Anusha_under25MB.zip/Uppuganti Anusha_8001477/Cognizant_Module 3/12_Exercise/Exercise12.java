// Exercise 12
// Implementation placeholder for user practice
public class Exercise12 {
    public static void main(String[] args) {
        System.out.println("Exercise 12 placeholder");
    }
}
