// Exercise 20
// Implementation placeholder for user practice
public class Exercise20 {
    public static void main(String[] args) {
        System.out.println("Exercise 20 placeholder");
    }
}
