// Exercise 27
// Implementation placeholder for user practice
public class Exercise27 {
    public static void main(String[] args) {
        System.out.println("Exercise 27 placeholder");
    }
}
