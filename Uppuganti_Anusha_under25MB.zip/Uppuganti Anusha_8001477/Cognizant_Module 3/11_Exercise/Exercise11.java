// Exercise 11
// Implementation placeholder for user practice
public class Exercise11 {
    public static void main(String[] args) {
        System.out.println("Exercise 11 placeholder");
    }
}
