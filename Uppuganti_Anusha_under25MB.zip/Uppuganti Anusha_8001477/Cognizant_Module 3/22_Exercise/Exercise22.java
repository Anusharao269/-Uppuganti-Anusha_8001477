// Exercise 22
// Implementation placeholder for user practice
public class Exercise22 {
    public static void main(String[] args) {
        System.out.println("Exercise 22 placeholder");
    }
}
