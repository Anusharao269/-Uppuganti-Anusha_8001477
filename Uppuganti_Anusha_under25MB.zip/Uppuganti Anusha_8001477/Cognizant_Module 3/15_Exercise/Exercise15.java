// Exercise 15
// Implementation placeholder for user practice
public class Exercise15 {
    public static void main(String[] args) {
        System.out.println("Exercise 15 placeholder");
    }
}
