import java.util.Scanner;
import java.util.Random;

public class Game {
    public static void main(String[] args) {
        Random r = new Random();
        int num = r.nextInt(100) + 1;
        Scanner sc = new Scanner(System.in);

        int guess;
        do {
            guess = sc.nextInt();
            if(guess > num) System.out.println("Too high");
            else if(guess < num) System.out.println("Too low");
        } while(guess != num);

        System.out.println("Correct!");
    }
}
