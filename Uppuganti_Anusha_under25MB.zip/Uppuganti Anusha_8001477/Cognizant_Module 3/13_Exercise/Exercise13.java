// Exercise 13
// Implementation placeholder for user practice
public class Exercise13 {
    public static void main(String[] args) {
        System.out.println("Exercise 13 placeholder");
    }
}
