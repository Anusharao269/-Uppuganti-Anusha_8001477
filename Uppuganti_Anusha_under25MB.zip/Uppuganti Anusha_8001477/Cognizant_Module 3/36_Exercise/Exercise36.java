// Exercise 36
// Implementation placeholder for user practice
public class Exercise36 {
    public static void main(String[] args) {
        System.out.println("Exercise 36 placeholder");
    }
}
