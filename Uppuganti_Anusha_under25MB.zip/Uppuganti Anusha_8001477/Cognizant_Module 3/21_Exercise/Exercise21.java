// Exercise 21
// Implementation placeholder for user practice
public class Exercise21 {
    public static void main(String[] args) {
        System.out.println("Exercise 21 placeholder");
    }
}
