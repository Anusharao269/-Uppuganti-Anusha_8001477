// Exercise 17
// Implementation placeholder for user practice
public class Exercise17 {
    public static void main(String[] args) {
        System.out.println("Exercise 17 placeholder");
    }
}
