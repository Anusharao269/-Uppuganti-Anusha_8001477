// Exercise 14
// Implementation placeholder for user practice
public class Exercise14 {
    public static void main(String[] args) {
        System.out.println("Exercise 14 placeholder");
    }
}
